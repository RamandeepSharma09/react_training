import React from 'react';


class About extends React.Component {
   

   
    render() {
        return (
            <div>
            dbvnfvdnf
            </div>
        );
    }
}



export default About;
