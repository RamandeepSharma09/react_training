/*
 * @file: constants.js
 * @description: It Contain action types Related Action.
 * @author: Jasdeep Singh
 */

/************ LISTING *************/
export const LISTING = 'LISTING';